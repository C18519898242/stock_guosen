from setuptools import setup, find_packages

setup(
    name="stock_guosen",
    version="0.3",
    packages=find_packages(),
    install_requires=[
        # 添加你的包依赖的其他包，例如：
        # "requests",
    ],
)


